BUILD:
1. Cài JDK 21.
2. Trong thư mục này chạy: gradle build   (hoặc ./gradlew build nếu có wrapper)
3. Jar nằm ở build/libs/lavender-hack-1.0.0.jar
4. Bỏ vào mods cùng Fabric Loader 0.16.10 + Fabric API cho 1.21.5.

SỬ DỤNG: nhấn Right Shift mở menu.
  Chuột trái = bật/tắt module, tăng giá trị setting
  Chuột phải = mở setting của module, giảm giá trị setting
