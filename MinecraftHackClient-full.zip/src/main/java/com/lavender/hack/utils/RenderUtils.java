package com.lavender.hack.utils;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class RenderUtils {
    public static WorldRenderContext ctx;

    public static void line(Vec3d a, Vec3d b, float r, float g, float bl) {
        if (ctx == null || ctx.consumers() == null) return;
        Vec3d cam = ctx.camera().getPos();
        MatrixStack.Entry e = ctx.matrixStack().peek();
        VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        Vec3d d = b.subtract(a);
        Vec3d n = d.lengthSquared() == 0 ? new Vec3d(0, 1, 0) : d.normalize();
        vc.vertex(e, (float)(a.x - cam.x), (float)(a.y - cam.y), (float)(a.z - cam.z))
                .color(r, g, bl, 1f).normal(e, (float)n.x, (float)n.y, (float)n.z);
        vc.vertex(e, (float)(b.x - cam.x), (float)(b.y - cam.y), (float)(b.z - cam.z))
                .color(r, g, bl, 1f).normal(e, (float)n.x, (float)n.y, (float)n.z);
    }

    public static void box(Box bx, float r, float g, float b) {
        Vec3d[] c = {
            new Vec3d(bx.minX, bx.minY, bx.minZ), new Vec3d(bx.maxX, bx.minY, bx.minZ),
            new Vec3d(bx.maxX, bx.minY, bx.maxZ), new Vec3d(bx.minX, bx.minY, bx.maxZ),
            new Vec3d(bx.minX, bx.maxY, bx.minZ), new Vec3d(bx.maxX, bx.maxY, bx.minZ),
            new Vec3d(bx.maxX, bx.maxY, bx.maxZ), new Vec3d(bx.minX, bx.maxY, bx.maxZ)
        };
        for (int i = 0; i < 4; i++) {
            line(c[i], c[(i + 1) % 4], r, g, b);
            line(c[i + 4], c[(i + 1) % 4 + 4], r, g, b);
            line(c[i], c[i + 4], r, g, b);
        }
    }
}
