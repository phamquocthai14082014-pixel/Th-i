package com.lavender.hack;

import com.lavender.hack.modules.combat.*;
import com.lavender.hack.modules.movement.*;
import com.lavender.hack.modules.render.*;
import com.lavender.hack.modules.world.*;
import com.lavender.hack.modules.misc.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        add(new CrystalAura()); add(new AutoCrystal()); add(new KillAura());
        add(new AutoTotem()); add(new Criticals()); add(new AntiCrystal());
        add(new Speed()); add(new Fly()); add(new NoFall()); add(new Sprint());
        add(new ESP()); add(new Tracers()); add(new StorageESP()); add(new HoleESP());
        add(new Nuker()); add(new AutoMine()); add(new Scaffold()); add(new AutoTunnel());
        add(new AutoLog()); add(new AntiVoid()); add(new ChatSuffix());
    }

    public void add(Module m) { modules.add(m); }
    public void onTick() { for (Module m : modules) if (m.isEnabled()) m.onTick(); }
    public void onRender() { for (Module m : modules) if (m.isEnabled()) m.onRender(); }
    public List<Module> getModules() { return modules; }

    public Module getModule(String name) {
        for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    public List<Module> getModulesByCategory(Module.Category cat) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) if (m.getCategory() == cat) result.add(m);
        return result;
    }
}
