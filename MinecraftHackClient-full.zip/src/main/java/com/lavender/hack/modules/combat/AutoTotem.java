package com.lavender.hack.modules.combat;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting delay = new Setting("Delay", 50, 0, 500);
    private long lastSwitch = 0;

    public AutoTotem() {
        super("AutoTotem", "Tự động thay totem vào offhand", Category.COMBAT);
        addSetting(delay);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        if (now - lastSwitch < delay.getNumber()) return;
        if (mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) return;

        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                int slot = i < 9 ? i + 36 : i;
                int syncId = mc.player.playerScreenHandler.syncId;
                mc.interactionManager.clickSlot(syncId, slot, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(syncId, 45, 0, SlotActionType.PICKUP, mc.player);
                lastSwitch = now;
                return;
            }
        }
    }
}
