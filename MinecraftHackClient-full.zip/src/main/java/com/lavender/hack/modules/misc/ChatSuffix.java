package com.lavender.hack.modules.misc;

import com.lavender.hack.Module;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;

public class ChatSuffix extends Module {
    private static final String SUFFIX = " | Lavender";

    public ChatSuffix() {
        super("ChatSuffix", "Thêm đuôi vào tin nhắn chat", Category.MISC);
        ClientSendMessageEvents.MODIFY_CHAT.register(msg -> isEnabled() ? msg + SUFFIX : msg);
    }
}
