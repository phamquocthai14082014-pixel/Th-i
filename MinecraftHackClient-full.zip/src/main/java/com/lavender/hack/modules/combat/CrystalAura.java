package com.lavender.hack.modules.combat;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class CrystalAura extends Module {
    private final Setting range = new Setting("Range", 5.0, 1.0, 10.0);
    private final Setting placeDelay = new Setting("PlaceDelay", 50, 0, 500);
    private final Setting breakDelay = new Setting("BreakDelay", 50, 0, 500);
    private final Setting autoPlace = new Setting("AutoPlace", true);
    private final Setting autoBreak = new Setting("AutoBreak", true);
    private final Setting rotate = new Setting("Rotate", true);

    private long lastPlace = 0;
    private long lastBreak = 0;

    public CrystalAura() {
        super("CrystalAura", "Tự động đặt và phá crystal", Category.COMBAT);
        addSetting(range); addSetting(placeDelay); addSetting(breakDelay);
        addSetting(autoPlace); addSetting(autoBreak); addSetting(rotate);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        long now = System.currentTimeMillis();

        if (autoBreak.getBoolean() && now - lastBreak >= breakDelay.getNumber()) {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof EndCrystalEntity) {
                    double dist = mc.player.distanceTo(e);
                    if (dist <= range.getNumber()) {
                        if (rotate.getBoolean()) rotateTo(e.getPos());
                        mc.interactionManager.attackEntity(mc.player, e);
                        mc.player.swingHand(Hand.MAIN_HAND);
                        lastBreak = now;
                        break;
                    }
                }
            }
        }

        if (autoPlace.getBoolean() && now - lastPlace >= placeDelay.getNumber()) {
            if (mc.player.getMainHandStack().getItem() != Items.END_CRYSTAL) {
                int slot = findCrystalSlot();
                if (slot != -1) mc.player.getInventory().selectedSlot = slot;
                else return;
            }

            PlayerEntity target = findTarget();
            if (target == null) return;

            BlockPos base = findPlacePos(target);
            if (base != null) {
                if (rotate.getBoolean()) {
                    rotateTo(new Vec3d(base.getX() + 0.5, base.getY() + 0.5, base.getZ() + 0.5));
                }
                BlockPos crystalPos = base.up();
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                        new net.minecraft.util.hit.BlockHitResult(
                                new Vec3d(crystalPos.getX() + 0.5, crystalPos.getY(), crystalPos.getZ() + 0.5),
                                net.minecraft.util.math.Direction.UP, base, false));
                mc.player.swingHand(Hand.MAIN_HAND);
                lastPlace = now;
            }
        }
    }

    private int findCrystalSlot() {
        for (int i = 0; i < 9; i++)
            if (mc.player.getInventory().getStack(i).getItem() == Items.END_CRYSTAL) return i;
        return -1;
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double bestDist = range.getNumber();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isDead()) continue;
            double d = mc.player.distanceTo(p);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }

    private BlockPos findPlacePos(PlayerEntity target) {
        BlockPos p = target.getBlockPos();
        BlockPos[] positions = {p.down(), p.north(), p.south(), p.east(), p.west()};
        for (BlockPos pos : positions) {
            if (mc.world.getBlockState(pos).isSolidBlock(mc.world, pos) && mc.world.isAir(pos.up()))
                return pos;
        }
        return null;
    }

    private void rotateTo(Vec3d pos) {
        double dx = pos.x - mc.player.getX();
        double dy = pos.y - (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()));
        double dz = pos.z - mc.player.getZ();
        double dist = Math.sqrt(dx*dx + dz*dz);
        mc.player.setYaw((float)(Math.toDegrees(Math.atan2(dz, dx)) - 90));
        mc.player.setPitch((float)(-Math.toDegrees(Math.atan2(dy, dist))));
    }
}
