package com.lavender.hack.modules.world;

import com.lavender.hack.Module;
import net.minecraft.util.hit.HitResult;

public class AutoMine extends Module {
    public AutoMine() {
        super("AutoMine", "Tự giữ chuột đào block đang nhìn", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean onBlock = mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK;
        mc.options.attackKey.setPressed(onBlock);
    }

    @Override
    public void onDisable() {
        mc.options.attackKey.setPressed(false);
    }
}
