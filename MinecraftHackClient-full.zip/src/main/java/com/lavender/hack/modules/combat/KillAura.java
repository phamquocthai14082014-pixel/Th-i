package com.lavender.hack.modules.combat;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {
    private final Setting range = new Setting("Range", 3.5, 1.0, 6.0);
    private final Setting cps = new Setting("CPS", 12.0, 1.0, 20.0);
    private final Setting rotate = new Setting("Rotate", true);
    private final Setting playersOnly = new Setting("PlayersOnly", true);
    private long lastAttack = 0;

    public KillAura() {
        super("KillAura", "Tự động đánh entity xung quanh", Category.COMBAT);
        addSetting(range); addSetting(cps); addSetting(rotate); addSetting(playersOnly);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        long now = System.currentTimeMillis();
        long delay = (long)(1000.0 / cps.getNumber());
        if (now - lastAttack < delay) return;

        Entity target = null;
        double best = range.getNumber();
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            if (playersOnly.getBoolean() && !(e instanceof PlayerEntity)) continue;
            if (((LivingEntity) e).isDead()) continue;
            double d = mc.player.distanceTo(e);
            if (d < best) { best = d; target = e; }
        }

        if (target != null) {
            if (rotate.getBoolean()) rotateTo(target.getPos());
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            lastAttack = now;
        }
    }

    private void rotateTo(Vec3d pos) {
        double dx = pos.x - mc.player.getX();
        double dy = (pos.y + 1) - (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()));
        double dz = pos.z - mc.player.getZ();
        double dist = Math.sqrt(dx*dx + dz*dz);
        mc.player.setYaw((float)(Math.toDegrees(Math.atan2(dz, dx)) - 90));
        mc.player.setPitch((float)(-Math.toDegrees(Math.atan2(dy, dist))));
    }
}
