package com.lavender.hack.modules.render;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class ESP extends Module {
    private final Setting playersOnly = new Setting("PlayersOnly", true);

    public ESP() {
        super("ESP", "Làm entity phát sáng xuyên tường", Category.RENDER);
        addSetting(playersOnly);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            if (playersOnly.getBoolean() && !(e instanceof PlayerEntity)) continue;
            e.setGlowing(true);
        }
    }

    @Override
    public void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) e.setGlowing(false);
    }
}
