package com.lavender.hack.modules.combat;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Hand;

public class AntiCrystal extends Module {
    private final Setting range = new Setting("Range", 5.5, 1.0, 8.0);
    private final Setting delay = new Setting("Delay", 50, 0, 500);
    private long last = 0;

    public AntiCrystal() {
        super("AntiCrystal", "Phá crystal đang ở gần mình", Category.COMBAT);
        addSetting(range); addSetting(delay);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        long now = System.currentTimeMillis();
        if (now - last < delay.getNumber()) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof EndCrystalEntity && mc.player.distanceTo(e) <= range.getNumber()) {
                mc.interactionManager.attackEntity(mc.player, e);
                mc.player.swingHand(Hand.MAIN_HAND);
                last = now;
                return;
            }
        }
    }
}
