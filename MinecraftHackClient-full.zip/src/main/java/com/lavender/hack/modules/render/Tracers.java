package com.lavender.hack.modules.render;

import com.lavender.hack.Module;
import com.lavender.hack.utils.RenderUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Tracers extends Module {
    public Tracers() {
        super("Tracers", "Vẽ đường tới người chơi khác", Category.RENDER);
    }

    @Override
    public void onRender() {
        if (mc.world == null || mc.player == null || RenderUtils.ctx == null) return;
        Vec3d start = RenderUtils.ctx.camera().getPos().add(mc.player.getRotationVec(1f));
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Vec3d end = p.getPos().add(0, p.getHeight() / 2, 0);
            RenderUtils.line(start, end, 1f, 0.2f, 0.2f);
        }
    }
}
