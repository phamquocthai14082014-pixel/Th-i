package com.lavender.hack.modules.render;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import com.lavender.hack.utils.RenderUtils;
import net.minecraft.block.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

public class StorageESP extends Module {
    private final Setting radius = new Setting("Radius", 20, 5, 40);
    private final List<BlockPos> found = new ArrayList<>();
    private int tick = 0;

    public StorageESP() {
        super("StorageESP", "Hiện rương, thùng, shulker", Category.RENDER);
        addSetting(radius);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        if (tick++ % 20 != 0) return;
        found.clear();
        int r = (int) radius.getNumber();
        BlockPos c = mc.player.getBlockPos();
        for (BlockPos pos : BlockPos.iterate(c.add(-r, -r, -r), c.add(r, r, r))) {
            Block b = mc.world.getBlockState(pos).getBlock();
            if (b instanceof ChestBlock || b instanceof EnderChestBlock
                    || b instanceof BarrelBlock || b instanceof ShulkerBoxBlock) {
                found.add(pos.toImmutable());
            }
        }
    }

    @Override
    public void onRender() {
        for (BlockPos p : found) RenderUtils.box(new Box(p), 1f, 0.8f, 0f);
    }

    @Override
    public void onDisable() { found.clear(); }
}
