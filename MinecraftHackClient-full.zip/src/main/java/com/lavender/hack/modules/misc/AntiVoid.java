package com.lavender.hack.modules.misc;

import com.lavender.hack.Module;
import net.minecraft.util.math.Vec3d;

public class AntiVoid extends Module {
    public AntiVoid() {
        super("AntiVoid", "Bật người lên khi sắp rơi xuống void", Category.MISC);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.getY() < mc.world.getBottomY() + 2 && mc.player.getVelocity().y < 0) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.8, v.z);
            mc.player.fallDistance = 0;
        }
    }
}
