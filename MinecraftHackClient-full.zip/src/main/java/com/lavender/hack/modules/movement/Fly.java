package com.lavender.hack.modules.movement;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;

public class Fly extends Module {
    private final Setting speed = new Setting("Speed", 0.05, 0.02, 0.5);

    public Fly() {
        super("Fly", "Bay như creative", Category.MOVEMENT);
        addSetting(speed);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying = true;
        mc.player.getAbilities().setFlySpeed((float) speed.getNumber());
    }

    @Override
    public void onDisable() {
        if (mc.player == null) return;
        mc.player.getAbilities().setFlySpeed(0.05f);
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
        }
    }
}
