package com.lavender.hack.modules.world;

import com.lavender.hack.Module;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
    public Scaffold() {
        super("Scaffold", "Tự đặt block dưới chân", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        BlockPos target = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() - 1, mc.player.getZ());
        if (!mc.world.getBlockState(target).isReplaceable()) return;

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof BlockItem) { slot = i; break; }
        }
        if (slot == -1) return;
        mc.player.getInventory().selectedSlot = slot;

        for (Direction d : Direction.values()) {
            BlockPos n = target.offset(d);
            if (mc.world.getBlockState(n).isSolidBlock(mc.world, n)) {
                Direction face = d.getOpposite();
                Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
                mc.player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }
    }
}
