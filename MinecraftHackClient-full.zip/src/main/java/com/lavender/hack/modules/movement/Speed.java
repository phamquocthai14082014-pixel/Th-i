package com.lavender.hack.modules.movement;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final Setting speed = new Setting("Speed", 0.3, 0.1, 1.0);

    public Speed() {
        super("Speed", "Chạy nhanh hơn", Category.MOVEMENT);
        addSetting(speed);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        float fwd = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        float side = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (fwd == 0 && side == 0) return;
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double dx = (-sin * fwd + cos * side);
        double dz = (cos * fwd + sin * side);
        double len = Math.sqrt(dx * dx + dz * dz);
        double s = speed.getNumber();
        Vec3d v = mc.player.getVelocity();
        mc.player.setVelocity(dx / len * s, v.y, dz / len * s);
    }
}
