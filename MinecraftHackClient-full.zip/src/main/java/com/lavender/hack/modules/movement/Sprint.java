package com.lavender.hack.modules.movement;

import com.lavender.hack.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Tự động chạy nhanh", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.options.forwardKey.isPressed() && !mc.player.isSneaking()
                && !mc.player.horizontalCollision && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
