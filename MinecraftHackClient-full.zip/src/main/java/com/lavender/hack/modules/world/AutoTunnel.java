package com.lavender.hack.modules.world;

import com.lavender.hack.Module;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class AutoTunnel extends Module {
    public AutoTunnel() {
        super("AutoTunnel", "Tự đào hầm 1x2 phía trước", Category.WORLD);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        Direction dir = mc.player.getHorizontalFacing();
        BlockPos feet = mc.player.getBlockPos();
        boolean blocked = false;
        for (int i = 1; i <= 2 && !blocked; i++) {
            for (int h = 0; h <= 1; h++) {
                BlockPos p = feet.offset(dir, i).up(h);
                if (!mc.world.isAir(p) && mc.world.getBlockState(p).getHardness(mc.world, p) >= 0) {
                    mc.interactionManager.updateBlockBreakingProgress(p, dir.getOpposite());
                    mc.player.swingHand(Hand.MAIN_HAND);
                    blocked = true;
                    break;
                }
            }
        }
        mc.options.forwardKey.setPressed(!blocked);
    }

    @Override
    public void onDisable() {
        mc.options.forwardKey.setPressed(false);
    }
}
