package com.lavender.hack.modules.combat;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Hand;

public class AutoCrystal extends Module {
    private final Setting range = new Setting("Range", 4.5, 1.0, 8.0);
    private final Setting targetRange = new Setting("TargetRange", 10.0, 1.0, 20.0);
    private long lastAction = 0;

    public AutoCrystal() {
        super("AutoCrystal", "Đặt và phá crystal siêu nhanh", Category.COMBAT);
        addSetting(range); addSetting(targetRange);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        long now = System.currentTimeMillis();
        if (now - lastAction < 30) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof EndCrystalEntity && mc.player.distanceTo(e) <= range.getNumber()) {
                mc.interactionManager.attackEntity(mc.player, e);
                mc.player.swingHand(Hand.MAIN_HAND);
                lastAction = now;
                return;
            }
        }
    }
}
