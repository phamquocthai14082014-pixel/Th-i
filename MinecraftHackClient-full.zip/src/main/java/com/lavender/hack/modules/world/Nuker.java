package com.lavender.hack.modules.world;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class Nuker extends Module {
    private final Setting range = new Setting("Range", 4.0, 1.0, 6.0);

    public Nuker() {
        super("Nuker", "Tự phá block xung quanh", Category.WORLD);
        addSetting(range);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        int r = (int) Math.ceil(range.getNumber());
        BlockPos c = mc.player.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.iterate(c.add(-r, -r, -r), c.add(r, r, r))) {
            if (mc.world.isAir(pos)) continue;
            if (mc.world.getBlockState(pos).getHardness(mc.world, pos) < 0) continue;
            double d = pos.getSquaredDistance(mc.player.getEyePos());
            if (d <= range.getNumber() * range.getNumber() && d < bestD) { bestD = d; best = pos.toImmutable(); }
        }
        if (best != null) {
            mc.interactionManager.updateBlockBreakingProgress(best, Direction.UP);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
