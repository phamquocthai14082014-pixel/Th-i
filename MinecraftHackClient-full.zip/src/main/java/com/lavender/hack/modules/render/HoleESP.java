package com.lavender.hack.modules.render;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import com.lavender.hack.utils.RenderUtils;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

public class HoleESP extends Module {
    private final Setting radius = new Setting("Radius", 8, 3, 16);
    private final List<BlockPos> holes = new ArrayList<>();
    private final List<Boolean> safe = new ArrayList<>();
    private int tick = 0;

    public HoleESP() {
        super("HoleESP", "Hiện hố bedrock/obsidian", Category.RENDER);
        addSetting(radius);
    }

    private boolean isSolid(BlockPos p) {
        var b = mc.world.getBlockState(p).getBlock();
        return b == Blocks.BEDROCK || b == Blocks.OBSIDIAN;
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        if (tick++ % 10 != 0) return;
        holes.clear(); safe.clear();
        int r = (int) radius.getNumber();
        BlockPos c = mc.player.getBlockPos();
        for (BlockPos pos : BlockPos.iterate(c.add(-r, -3, -r), c.add(r, 3, r))) {
            if (!mc.world.isAir(pos) || !mc.world.isAir(pos.up())) continue;
            if (!isSolid(pos.down())) continue;
            boolean ok = true, bed = mc.world.getBlockState(pos.down()).isOf(Blocks.BEDROCK);
            for (Direction d : Direction.Type.HORIZONTAL) {
                BlockPos n = pos.offset(d);
                if (!isSolid(n)) { ok = false; break; }
                if (!mc.world.getBlockState(n).isOf(Blocks.BEDROCK)) bed = false;
            }
            if (ok) { holes.add(pos.toImmutable()); safe.add(bed); }
        }
    }

    @Override
    public void onRender() {
        for (int i = 0; i < holes.size(); i++) {
            BlockPos p = holes.get(i);
            Box b = new Box(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 0.05, p.getZ() + 1);
            if (safe.get(i)) RenderUtils.box(b, 0f, 1f, 0f); else RenderUtils.box(b, 1f, 0.5f, 0f);
        }
    }

    @Override
    public void onDisable() { holes.clear(); safe.clear(); }
}
