package com.lavender.hack.modules.misc;

import com.lavender.hack.Module;
import com.lavender.hack.Setting;
import net.minecraft.text.Text;

public class AutoLog extends Module {
    private final Setting health = new Setting("Health", 6.0, 1.0, 20.0);

    public AutoLog() {
        super("AutoLog", "Tự thoát server khi máu thấp", Category.MISC);
        addSetting(health);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (mc.player.getHealth() <= health.getNumber()) {
            mc.getNetworkHandler().getConnection().disconnect(Text.literal("AutoLog: máu còn " + mc.player.getHealth()));
            setEnabled(false);
        }
    }
}
