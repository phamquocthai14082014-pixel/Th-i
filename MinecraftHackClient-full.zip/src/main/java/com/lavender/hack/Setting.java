package com.lavender.hack;

public class Setting {
    public enum Type { BOOLEAN, NUMBER, MODE, STRING }

    private final String name;
    private final Type type;
    private Object value;
    private double min, max;
    private String[] modes;

    public Setting(String name, boolean defaultValue) {
        this.name = name; this.type = Type.BOOLEAN; this.value = defaultValue;
    }
    public Setting(String name, double defaultValue, double min, double max) {
        this.name = name; this.type = Type.NUMBER; this.value = defaultValue;
        this.min = min; this.max = max;
    }
    public Setting(String name, String defaultValue, String[] modes) {
        this.name = name; this.type = Type.MODE; this.value = defaultValue; this.modes = modes;
    }

    public String getName() { return name; }
    public Type getType() { return type; }
    public boolean getBoolean() { return (boolean) value; }
    public double getNumber() { return (double) value; }
    public String getMode() { return (String) value; }
    public void setValue(Object v) { this.value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public String[] getModes() { return modes; }
}
