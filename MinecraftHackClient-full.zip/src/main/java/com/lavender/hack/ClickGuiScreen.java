package com.lavender.hack;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    private static final int W = 110, H = 14, GAP = 6;
    private final Set<Module> expanded = new HashSet<>();

    public ClickGuiScreen() {
        super(Text.literal("Lavender"));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        int x = 10;
        for (Module.Category cat : Module.Category.values()) {
            int y = 10;
            ctx.fill(x, y, x + W, y + H, 0xFF6A3DB8);
            ctx.drawText(textRenderer, cat.getName(), x + 4, y + 3, 0xFFFFFFFF, false);
            y += H;
            for (Module m : HackClient.moduleManager.getModulesByCategory(cat)) {
                ctx.fill(x, y, x + W, y + H, m.isEnabled() ? 0xFF8F5FE8 : 0xFF222222);
                ctx.drawText(textRenderer, m.getName(), x + 4, y + 3, 0xFFFFFFFF, false);
                y += H;
                if (expanded.contains(m)) {
                    for (Setting s : m.getSettings()) {
                        ctx.fill(x, y, x + W, y + H, 0xFF111111);
                        ctx.drawText(textRenderer, s.getName() + ": " + valueText(s), x + 8, y + 3, 0xFFCCCCCC, false);
                        y += H;
                    }
                }
            }
            x += W + GAP;
        }
        super.render(ctx, mx, my, delta);
    }

    private String valueText(Setting s) {
        return switch (s.getType()) {
            case BOOLEAN -> s.getBoolean() ? "ON" : "OFF";
            case NUMBER -> String.format("%.2f", s.getNumber());
            default -> String.valueOf(s.getMode());
        };
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = 10;
        for (Module.Category cat : Module.Category.values()) {
            int y = 10 + H;
            for (Module m : HackClient.moduleManager.getModulesByCategory(cat)) {
                if (inside(mx, my, x, y)) {
                    if (button == 0) m.toggle();
                    else if (button == 1) { if (!expanded.remove(m)) expanded.add(m); }
                    return true;
                }
                y += H;
                if (expanded.contains(m)) {
                    for (Setting s : m.getSettings()) {
                        if (inside(mx, my, x, y)) { adjust(s, button == 0 ? 1 : -1); return true; }
                        y += H;
                    }
                }
            }
            x += W + GAP;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void adjust(Setting s, int dir) {
        if (s.getType() == Setting.Type.BOOLEAN) {
            s.setValue(!s.getBoolean());
        } else if (s.getType() == Setting.Type.NUMBER) {
            double step = (s.getMax() - s.getMin()) / 10.0;
            double v = Math.max(s.getMin(), Math.min(s.getMax(), s.getNumber() + dir * step));
            s.setValue(v);
        } else if (s.getType() == Setting.Type.MODE) {
            String[] modes = s.getModes();
            int i = java.util.Arrays.asList(modes).indexOf(s.getMode());
            s.setValue(modes[(i + dir + modes.length) % modes.length]);
        }
    }

    private boolean inside(double mx, double my, int x, int y) {
        return mx >= x && mx <= x + W && my >= y && my <= y + H;
    }

    @Override
    public boolean shouldPause() { return false; }
}
