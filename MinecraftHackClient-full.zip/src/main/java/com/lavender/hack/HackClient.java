package com.lavender.hack;

import com.lavender.hack.utils.RenderUtils;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class HackClient implements ClientModInitializer {
    public static HackClient INSTANCE;
    public static ModuleManager moduleManager;
    public static KeyBinding clickGuiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        moduleManager = new ModuleManager();
        moduleManager.init();

        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lavender.clickgui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.lavender"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (clickGuiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            moduleManager.onTick();
        });

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            RenderUtils.ctx = ctx;
            moduleManager.onRender();
        });
    }
}
